<!-- live server -->
<?php
// define('DB_SERVER','localhost');
// define('DB_USER','u776132630_hotscaped');
// define('DB_PASS' ,'KCESSnaiag2@');
// define('DB_NAME','u776132630_hotscaped');
// $con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
// // Check connection
// if (mysqli_connect_errno())
// {
//  echo "Failed to connect to MySQL: " . mysqli_connect_error();
// }
// ?>

<!-- localhost -->
<?php
define('DB_SERVER','localhost');
define('DB_USER','root');
define('DB_PASS' ,'');
define('DB_NAME','hotscaped');
$con = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
// Check connection
if (mysqli_connect_errno())
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>